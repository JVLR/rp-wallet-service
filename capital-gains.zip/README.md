# Capital Gain Calculator - Nubank Technical Challenge

Este projeto implementa uma calculadora de ganho de capital em Java 21, seguindo as regras fiscais brasileiras para operações de compra e venda de ações.

## 🎯 Objetivo

Implementar um programa de linha de comando (CLI) que receba listas de operações financeiras via entrada padrão (stdin) e retorne os impostos devidos via saída padrão (stdout), seguindo as regras de ganho de capital.

## 📋 Regras de Negócio

- **Imposto**: 20% sobre o lucro apurado em vendas
- **Isenção**: Vendas com valor total ≤ R$ 20.000 são isentas de imposto
- **Preço Médio Ponderado**: Utilizado para cálculo do custo de aquisição
- **Compensação de Perdas**: Prejuízos podem ser acumulados e compensados em lucros futuros
- **Operações de Compra**: Não geram imposto

## 🏗️ Estrutura do Projeto

```
src/
├── main/java/com/nubank/
│   ├── Main.java                    # Classe principal (CLI)
│   ├── Operation.java               # Representa uma operação financeira
│   ├── TaxResult.java               # Representa o resultado do imposto
│   └── CapitalGainCalculator.java   # Lógica de cálculo de ganho de capital
└── test/java/com/nubank/
    ├── CapitalGainCalculatorTest.java    # Testes unitários
    └── MainIntegrationTest.java          # Testes de integração
```

## 🧠 Decisões Técnicas e Arquiteturais

### **1. Linguagem e Versão**
- **Java 21**: Escolhido pela maturidade, performance e recursos modernos
- **Maven**: Para gerenciamento de dependências e build automation

### **2. Arquitetura**
- **Separação de Responsabilidades**: Cada classe tem uma responsabilidade bem definida
- **Modelo de Dados Simples**: Classes `Operation` e `TaxResult` para representar dados
- **Lógica de Negócio Centralizada**: `CapitalGainCalculator` contém toda a lógica fiscal
- **CLI Minimalista**: `Main` apenas orquestra entrada/saída

### **3. Precisão Numérica**
- **BigDecimal**: Utilizado para evitar problemas de precisão em cálculos financeiros
- **RoundingMode.HALF_UP**: Arredondamento padrão para cálculos fiscais
- **Escala de 2 casas decimais**: Padrão para valores monetários

### **4. Tratamento de Estado**
- **Estado In-Memory**: Mantido durante processamento de cada linha
- **Reset Automático**: Estado é resetado para cada nova simulação
- **Thread-Safe**: Cada instância é independente

## 📚 Justificativa para Frameworks/Bibliotecas

### **Jackson (jackson-databind)**
- **Justificativa**: Processamento JSON é essencial para o requisito stdin/stdout
- **Alternativa**: Implementar parser JSON manual seria complexo e propenso a erros
- **Benefício**: Biblioteca madura, testada e otimizada para performance

### **JUnit 5**
- **Justificativa**: Framework padrão para testes em Java
- **Escopo**: Apenas para testes (não afeta produção)
- **Benefício**: Facilita escrita e execução de testes unitários e de integração

## 🚀 Como Compilar e Executar

### Pré-requisitos

- Java 21 ou superior
- Maven 3.6 ou superior

### Compilação

```bash
mvn clean compile
```

### Execução

```bash
# Compilar e executar
mvn clean compile exec:java -Dexec.mainClass="com.nubank.Main"

# Ou compilar JAR e executar
mvn clean package
java -jar target/capital-gain-calculator-1.0.0.jar
```

### Uso via STDIN/STDOUT

```bash
# Exemplo de entrada
echo '[{"operation":"buy","unit-cost":10.00,"quantity":100},{"operation":"sell","unit-cost":15.00,"quantity":50},{"operation":"sell","unit-cost":15.00,"quantity":50}]' | java -jar target/capital-gain-calculator-1.0.0.jar

# Saída esperada
[{"tax":0.00},{"tax":0.00},{"tax":0.00}]
```

## 🧪 Como Executar os Testes

### Executar todos os testes

```bash
mvn test
```

### Executar testes específicos

```bash
# Apenas testes unitários
mvn test -Dtest=CapitalGainCalculatorTest

# Apenas testes de integração
mvn test -Dtest=MainIntegrationTest
```

### Cobertura de Testes

O projeto inclui:
- **16 testes unitários** cobrindo todos os cenários de negócio
- **3 testes de integração** validando o fluxo completo stdin/stdout
- **Cenários de borda** testados (isenção, compensação de perdas, etc.)

## 📝 Exemplos de Uso

### Caso 1: Lucro simples (isento por valor baixo)

**Entrada:**
```json
[{"operation":"buy","unit-cost":10.00,"quantity":100},{"operation":"sell","unit-cost":15.00,"quantity":50},{"operation":"sell","unit-cost":15.00,"quantity":50}]
```

**Saída:**
```json
[{"tax":0.00},{"tax":0.00},{"tax":0.00}]
```

### Caso 2: Lucro acima do limite de isenção

**Entrada:**
```json
[{"operation":"buy","unit-cost":10.00,"quantity":1000},{"operation":"sell","unit-cost":25.00,"quantity":1000}]
```

**Saída:**
```json
[{"tax":0.00},{"tax":3000.00}]
```

### Caso 3: Compensação de prejuízos

**Entrada:**
```json
[{"operation":"buy","unit-cost":10.00,"quantity":1000},{"operation":"sell","unit-cost":5.00,"quantity":500},{"operation":"sell","unit-cost":20.00,"quantity":500}]
```

**Saída:**
```json
[{"tax":0.00},{"tax":0.00},{"tax":0.00}]
```

## 🐳 Docker (Opcional)

### Build da imagem

```bash
docker build -t capital-gain-calculator .
```

### Execução

```bash
echo '[{"operation":"buy","unit-cost":10.00,"quantity":100},{"operation":"sell","unit-cost":15.00,"quantity":50}]' | docker run -i capital-gain-calculator
```

## 📊 Notas Importantes para Avaliação

### **1. Simplicidade**
- Projeto pequeno (635 linhas de código)
- Estrutura clara e fácil de entender
- Sem complexidade desnecessária

### **2. Elegância**
- Separação clara de responsabilidades
- Código limpo e bem organizado
- Nomes descritivos de classes e métodos

### **3. Operacional**
- Resolve completamente o problema proposto
- Cobre todos os casos de borda
- Estrutura permite fácil extensão

### **4. Qualidade**
- 17 testes passando (100% de sucesso)
- Cobertura abrangente de cenários
- Validação manual confirmada

### **5. Boas Práticas**
- Testes unitários e de integração
- Documentação completa
- Mínimo de dependências externas

### **6. Limitações Assumidas**
- Não há tratamento de erros de JSON (conforme especificação)
- Assume dados de entrada válidos
- Foco na lógica de negócio principal

### **7. Performance**
- Processamento eficiente com BigDecimal
- Sem operações desnecessárias
- Estado resetado a cada simulação

## 🔧 Tecnologias Utilizadas

- **Java 21**: Linguagem principal
- **Maven**: Build automation
- **Jackson**: Processamento JSON
- **JUnit 5**: Framework de testes
- **Docker**: Containerização (opcional)

## 📄 Licença

Este projeto foi desenvolvido como parte do desafio técnico do Nubank.
