package com.nubank;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class Main {

    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final CapitalGainCalculator calculator = new CapitalGainCalculator();

    static {
        objectMapper.disable(SerializationFeature.INDENT_OUTPUT);
    }

    public static void main(String[] args) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.trim().isEmpty()) {
                    continue;
                }

                List<Operation> operations = objectMapper.readValue(
                    line,
                    new TypeReference<List<Operation>>() {}
                );

                calculator.reset();

                List<TaxResult> results = calculator.processOperations(operations);

                String output = objectMapper.writeValueAsString(results);
                System.out.println(output);
            }
        }
    }
}
