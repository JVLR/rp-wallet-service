package com.nubank;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.util.Objects;

public class TaxResult {

    @JsonProperty("tax")
    private BigDecimal tax;

    public TaxResult() {}

    public TaxResult(BigDecimal tax) {
        this.tax = tax;
    }

    public TaxResult(double tax) {
        this.tax = BigDecimal.valueOf(tax);
    }

    public BigDecimal getTax() {
        return tax;
    }

    public void setTax(BigDecimal tax) {
        this.tax = tax;
    }

    @Override
    public String toString() {
        return "TaxResult{" +
                "tax=" + tax +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        TaxResult that = (TaxResult) obj;
        return Objects.equals(tax, that.tax);
    }

    @Override
    public int hashCode() {
        return Objects.hash(tax);
    }
}
