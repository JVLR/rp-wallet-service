package com.nubank;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

public class CapitalGainCalculator {

    private static final BigDecimal TAX_RATE = new BigDecimal("0.20");
    private static final BigDecimal EXEMPTION_THRESHOLD = new BigDecimal("20000.00");
    private static final int DECIMAL_PLACES = 2;
    private static final BigDecimal ZERO_TAX = new BigDecimal("0.00");
    private static final BigDecimal ZERO_VALUE = new BigDecimal("0.00");

    private BigDecimal weightedAveragePrice;
    private int totalShares;
    private BigDecimal accumulatedLosses;

    public CapitalGainCalculator() {
        reset();
    }

    public void reset() {
        this.weightedAveragePrice = ZERO_VALUE;
        this.totalShares = 0;
        this.accumulatedLosses = ZERO_VALUE;
    }

    public List<TaxResult> processOperations(List<Operation> operations) {
        List<TaxResult> results = new ArrayList<>();

        for (Operation operation : operations) {
            TaxResult result = processOperation(operation);
            results.add(result);
        }

        return results;
    }

    public TaxResult processOperation(Operation operation) {
        if (operation.getOperation() == Operation.OperationType.BUY) {
            return processBuyOperation(operation);
        } else {
            return processSellOperation(operation);
        }
    }

    private TaxResult processBuyOperation(Operation operation) {
        BigDecimal newShares = BigDecimal.valueOf(operation.getQuantity());
        BigDecimal newTotalValue = operation.getTotalValue();

        BigDecimal currentTotalValue = weightedAveragePrice.multiply(BigDecimal.valueOf(totalShares));
        BigDecimal newTotalShares = BigDecimal.valueOf(totalShares).add(newShares);

        if (newTotalShares.compareTo(BigDecimal.ZERO) > 0) {
            weightedAveragePrice = currentTotalValue.add(newTotalValue)
                    .divide(newTotalShares, DECIMAL_PLACES, RoundingMode.HALF_UP);
        }

        totalShares += operation.getQuantity();

        return new TaxResult(ZERO_TAX);
    }

    private TaxResult processSellOperation(Operation operation) {
        BigDecimal sellQuantity = BigDecimal.valueOf(operation.getQuantity());
        BigDecimal totalSellValue = operation.getTotalValue();

        if (sellQuantity.compareTo(BigDecimal.valueOf(totalShares)) > 0) {
            throw new IllegalStateException("Cannot sell more shares than owned");
        }

        BigDecimal costBasis = weightedAveragePrice.multiply(sellQuantity);

        BigDecimal profit = totalSellValue.subtract(costBasis);

        totalShares -= operation.getQuantity();

        if (totalShares <= 0) {
            weightedAveragePrice = ZERO_VALUE;
            totalShares = 0;
        }

        BigDecimal taxableProfit = profit;
        if (profit.compareTo(BigDecimal.ZERO) > 0 && accumulatedLosses.compareTo(BigDecimal.ZERO) > 0) {
            if (accumulatedLosses.compareTo(profit) >= 0) {
                accumulatedLosses = accumulatedLosses.subtract(profit);
                taxableProfit = ZERO_VALUE;
            } else {
                taxableProfit = profit.subtract(accumulatedLosses);
                accumulatedLosses = ZERO_VALUE;
            }
        } else if (profit.compareTo(BigDecimal.ZERO) < 0) {
            accumulatedLosses = accumulatedLosses.add(profit.abs());
            taxableProfit = ZERO_VALUE;
        }

        if (totalSellValue.compareTo(EXEMPTION_THRESHOLD) <= 0) {
            return new TaxResult(ZERO_TAX);
        }

        BigDecimal tax = taxableProfit.multiply(TAX_RATE)
                .setScale(DECIMAL_PLACES, RoundingMode.HALF_UP);

        return new TaxResult(tax);
    }

    public BigDecimal getWeightedAveragePrice() {
        return weightedAveragePrice;
    }

    public int getTotalShares() {
        return totalShares;
    }

    public BigDecimal getAccumulatedLosses() {
        return accumulatedLosses;
    }
}
