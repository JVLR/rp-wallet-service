package com.nubank;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.util.Objects;

public class Operation {

    public enum OperationType {
        @JsonProperty("buy")
        BUY,
        @JsonProperty("sell")
        SELL
    }

    @JsonProperty("operation")
    private OperationType operation;

    @JsonProperty("unit-cost")
    private BigDecimal unitCost;

    @JsonProperty("quantity")
    private int quantity;

    public Operation() {}

    public Operation(OperationType operation, BigDecimal unitCost, int quantity) {
        this.operation = operation;
        this.unitCost = unitCost;
        this.quantity = quantity;
    }

    public OperationType getOperation() {
        return operation;
    }

    public void setOperation(OperationType operation) {
        this.operation = operation;
    }

    public BigDecimal getUnitCost() {
        return unitCost;
    }

    public void setUnitCost(BigDecimal unitCost) {
        this.unitCost = unitCost;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getTotalValue() {
        return unitCost.multiply(BigDecimal.valueOf(quantity));
    }

    @Override
    public String toString() {
        return "Operation{" +
                "operation=" + operation +
                ", unitCost=" + unitCost +
                ", quantity=" + quantity +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        Operation that = (Operation) obj;
        return quantity == that.quantity &&
                Objects.equals(operation, that.operation) &&
                Objects.equals(unitCost, that.unitCost);
    }

    @Override
    public int hashCode() {
        return Objects.hash(operation, unitCost, quantity);
    }
}
