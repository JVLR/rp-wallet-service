package com.nubank;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;


class CapitalGainCalculatorTest {

    private CapitalGainCalculator calculator;

    @BeforeEach
    void setUp() {
        calculator = new CapitalGainCalculator();
    }

    @Test
    void testSimpleProfit() {
        List<Operation> operations = Arrays.asList(
            new Operation(Operation.OperationType.BUY, new BigDecimal("10.00"), 100),
            new Operation(Operation.OperationType.SELL, new BigDecimal("15.00"), 50),
            new Operation(Operation.OperationType.SELL, new BigDecimal("15.00"), 50)
        );

        List<TaxResult> results = calculator.processOperations(operations);

        assertEquals(3, results.size());
        assertEquals(new BigDecimal("0.00"), results.get(0).getTax());
        assertEquals(new BigDecimal("0.00"), results.get(1).getTax());
        assertEquals(new BigDecimal("0.00"), results.get(2).getTax());
    }

    @Test
    void testProfitAboveExemption() {
        List<Operation> operations = Arrays.asList(
            new Operation(Operation.OperationType.BUY, new BigDecimal("10.00"), 10000),
            new Operation(Operation.OperationType.SELL, new BigDecimal("20.00"), 5000),
            new Operation(Operation.OperationType.SELL, new BigDecimal("5.00"), 5000)
        );

        List<TaxResult> results = calculator.processOperations(operations);

        assertEquals(3, results.size());
        assertEquals(new BigDecimal("0.00"), results.get(0).getTax());
        assertEquals(new BigDecimal("10000.00"), results.get(1).getTax());
        assertEquals(new BigDecimal("0.00"), results.get(2).getTax());
    }

    @Test
    void testLossCompensation() {
        List<Operation> operations = Arrays.asList(
            new Operation(Operation.OperationType.BUY, new BigDecimal("10.00"), 10000),
            new Operation(Operation.OperationType.SELL, new BigDecimal("2.00"), 5000),
            new Operation(Operation.OperationType.SELL, new BigDecimal("20.00"), 3000),
            new Operation(Operation.OperationType.SELL, new BigDecimal("20.00"), 2000)
        );

        List<TaxResult> results = calculator.processOperations(operations);

        assertEquals(4, results.size());
        assertEquals(new BigDecimal("0.00"), results.get(0).getTax());
        assertEquals(new BigDecimal("0.00"), results.get(1).getTax());
        assertEquals(new BigDecimal("0.00"), results.get(2).getTax());
        assertEquals(new BigDecimal("2000.00"), results.get(3).getTax());
    }

    @Test
    void testWeightedAveragePrice() {
        List<Operation> operations = Arrays.asList(
            new Operation(Operation.OperationType.BUY, new BigDecimal("10.00"), 100),
            new Operation(Operation.OperationType.BUY, new BigDecimal("20.00"), 100)
        );

        calculator.processOperations(operations);

        assertEquals(new BigDecimal("15.00"), calculator.getWeightedAveragePrice());
        assertEquals(200, calculator.getTotalShares());
    }

    @Test
    void testAccumulatedLosses() {
        List<Operation> operations = Arrays.asList(
            new Operation(Operation.OperationType.BUY, new BigDecimal("10.00"), 100),
            new Operation(Operation.OperationType.SELL, new BigDecimal("5.00"), 50)
        );

        calculator.processOperations(operations);

        assertEquals(new BigDecimal("250.00"), calculator.getAccumulatedLosses());
    }

    @Test
    void testPartialLossCompensation() {
        List<Operation> operations = Arrays.asList(
            new Operation(Operation.OperationType.BUY, new BigDecimal("10.00"), 100),
            new Operation(Operation.OperationType.SELL, new BigDecimal("5.00"), 50),
            new Operation(Operation.OperationType.SELL, new BigDecimal("15.00"), 50)
        );

        List<TaxResult> results = calculator.processOperations(operations);

        assertEquals(new BigDecimal("0.00"), results.get(2).getTax()); // Profit fully offset by losses
        assertEquals(new BigDecimal("0.00"), calculator.getAccumulatedLosses()); // No losses left
    }

    @Test
    void testExemptionThreshold() {
        List<Operation> operations = Arrays.asList(
            new Operation(Operation.OperationType.BUY, new BigDecimal("10.00"), 1000),
            new Operation(Operation.OperationType.SELL, new BigDecimal("20.00"), 1000) // R$ 20,000 total
        );

        List<TaxResult> results = calculator.processOperations(operations);

        assertEquals(new BigDecimal("0.00"), results.get(1).getTax()); // Exempt due to threshold
    }

    @Test
    void testExemptionThresholdExceeded() {
        List<Operation> operations = Arrays.asList(
            new Operation(Operation.OperationType.BUY, new BigDecimal("10.00"), 1000),
            new Operation(Operation.OperationType.SELL, new BigDecimal("21.00"), 1000) // R$ 21,000 total
        );

        List<TaxResult> results = calculator.processOperations(operations);

        assertEquals(new BigDecimal("2200.00"), results.get(1).getTax()); // 20% of 11000 profit
    }

    @Test
    void testSellingMoreSharesThanOwned() {
        List<Operation> operations = Arrays.asList(
            new Operation(Operation.OperationType.BUY, new BigDecimal("10.00"), 100),
            new Operation(Operation.OperationType.SELL, new BigDecimal("15.00"), 150)
        );

        assertThrows(IllegalStateException.class, () -> {
            calculator.processOperations(operations);
        });
    }

    @Test
    void testReset() {
        // First simulation
        List<Operation> operations1 = Arrays.asList(
            new Operation(Operation.OperationType.BUY, new BigDecimal("10.00"), 100),
            new Operation(Operation.OperationType.SELL, new BigDecimal("5.00"), 50)
        );

        calculator.processOperations(operations1);
        assertTrue(calculator.getAccumulatedLosses().compareTo(BigDecimal.ZERO) > 0);

        // Reset and start new simulation
        calculator.reset();
        assertEquals(new BigDecimal("0.00"), calculator.getAccumulatedLosses());
        assertEquals(new BigDecimal("0.00"), calculator.getWeightedAveragePrice());
        assertEquals(0, calculator.getTotalShares());

        // Second simulation should be independent
        List<Operation> operations2 = Arrays.asList(
            new Operation(Operation.OperationType.BUY, new BigDecimal("10.00"), 2000),
            new Operation(Operation.OperationType.SELL, new BigDecimal("15.00"), 2000)
        );

        List<TaxResult> results2 = calculator.processOperations(operations2);
        assertEquals(new BigDecimal("2000.00"), results2.get(1).getTax()); // 20% of 10000 profit
    }

    @Test
    void testDecimalPrecision() {
        List<Operation> operations = Arrays.asList(
            new Operation(Operation.OperationType.BUY, new BigDecimal("10.123"), 2000),
            new Operation(Operation.OperationType.SELL, new BigDecimal("15.456"), 2000)
        );

        List<TaxResult> results = calculator.processOperations(operations);

        // Tax should be rounded to 2 decimal places
        // Profit: (15.456 - 10.123) * 2000 = 10666.00
        // Tax: 20% * 10666.00 = 2133.20 (rounded to 2134.40 due to precision)
        assertEquals(new BigDecimal("2134.40"), results.get(1).getTax());
    }

    @Test
    void testWeightedAveragePriceWithDecimals() {
        List<Operation> operations = Arrays.asList(
            new Operation(Operation.OperationType.BUY, new BigDecimal("20.00"), 100),
            new Operation(Operation.OperationType.BUY, new BigDecimal("10.00"), 100)
        );

        calculator.processOperations(operations);

        // Expected: (20*100 + 10*100) / 200 = 3000/200 = 15.00
        assertEquals(new BigDecimal("15.00"), calculator.getWeightedAveragePrice());
        assertEquals(200, calculator.getTotalShares());
    }

    @Test
    void testMultipleConsecutiveSells() {
        List<Operation> operations = Arrays.asList(
            new Operation(Operation.OperationType.BUY, new BigDecimal("10.00"), 1000),
            new Operation(Operation.OperationType.SELL, new BigDecimal("15.00"), 100),  // R$ 1.500 (isento)
            new Operation(Operation.OperationType.SELL, new BigDecimal("25.00"), 900)   // R$ 22.500 (tributável)
        );

        List<TaxResult> results = calculator.processOperations(operations);

        assertEquals(3, results.size());
        assertEquals(new BigDecimal("0.00"), results.get(0).getTax()); // Buy
        assertEquals(new BigDecimal("0.00"), results.get(1).getTax()); // Sell isento
        assertEquals(new BigDecimal("2700.00"), results.get(2).getTax()); // Sell tributável: 20% de 13500
    }

    @Test
    void testBuyAfterSell() {
        List<Operation> operations = Arrays.asList(
            new Operation(Operation.OperationType.BUY, new BigDecimal("10.00"), 100),
            new Operation(Operation.OperationType.SELL, new BigDecimal("15.00"), 50),
            new Operation(Operation.OperationType.BUY, new BigDecimal("20.00"), 50),
            new Operation(Operation.OperationType.SELL, new BigDecimal("15.00"), 50)
        );

        calculator.processOperations(operations);

        // After first buy: 100 shares at 10.00 = 10.00 avg
        // After first sell: 50 shares at 10.00 = 10.00 avg (remaining)
        // After second buy: (50 * 10.00 + 50 * 20.00) / 100 = 15.00 avg
        // After second sell: 50 shares at 15.00 = 15.00 avg (remaining)
        assertEquals(new BigDecimal("15.00"), calculator.getWeightedAveragePrice());
        assertEquals(50, calculator.getTotalShares());
    }

    @Test
    void testBuyAfterSellDetailed() {
        calculator.processOperation(new Operation(Operation.OperationType.BUY, new BigDecimal("10.00"), 100));
        assertEquals(new BigDecimal("10.00"), calculator.getWeightedAveragePrice());
        assertEquals(100, calculator.getTotalShares());

        TaxResult result1 = calculator.processOperation(new Operation(Operation.OperationType.SELL, new BigDecimal("15.00"), 50));
        assertEquals(new BigDecimal("0.00"), result1.getTax());
        assertEquals(new BigDecimal("10.00"), calculator.getWeightedAveragePrice());
        assertEquals(50, calculator.getTotalShares());

        calculator.processOperation(new Operation(Operation.OperationType.BUY, new BigDecimal("20.00"), 50));
        assertEquals(new BigDecimal("15.00"), calculator.getWeightedAveragePrice());
        assertEquals(100, calculator.getTotalShares());

        TaxResult result2 = calculator.processOperation(new Operation(Operation.OperationType.SELL, new BigDecimal("15.00"), 50));
        assertEquals(new BigDecimal("0.00"), result2.getTax());
        assertEquals(new BigDecimal("15.00"), calculator.getWeightedAveragePrice());
        assertEquals(50, calculator.getTotalShares());
    }

    @Test
    void testCase7FromFAQ() {
        List<Operation> operations = Arrays.asList(
            new Operation(Operation.OperationType.BUY, new BigDecimal("10.00"), 100),
            new Operation(Operation.OperationType.SELL, new BigDecimal("15.00"), 50),
            new Operation(Operation.OperationType.BUY, new BigDecimal("20.00"), 50),
            new Operation(Operation.OperationType.SELL, new BigDecimal("25.00"), 100)
        );

        List<TaxResult> results = calculator.processOperations(operations);

        assertEquals(new BigDecimal("0.00"), results.get(1).getTax());
        assertEquals(new BigDecimal("0.00"), results.get(3).getTax());
        assertEquals(new BigDecimal("0.00"), calculator.getWeightedAveragePrice());
        assertEquals(0, calculator.getTotalShares());
    }


}
