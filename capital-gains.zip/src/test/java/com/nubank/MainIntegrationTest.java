package com.nubank;

import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;


class MainIntegrationTest {

    @Test
    void testCompleteIntegration() throws Exception {
        String input = "[{\"operation\":\"buy\",\"unit-cost\":10.00,\"quantity\":100},{\"operation\":\"sell\",\"unit-cost\":15.00,\"quantity\":50},{\"operation\":\"sell\",\"unit-cost\":15.00,\"quantity\":50}]";

        ByteArrayInputStream inputStream = new ByteArrayInputStream(input.getBytes(StandardCharsets.UTF_8));
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;

        try {
            System.setIn(inputStream);
            System.setOut(new PrintStream(outputStream));

            Main.main(new String[]{});

            String output = outputStream.toString(StandardCharsets.UTF_8).trim();

            assertTrue(output.contains("\"tax\":0.00") || output.contains("\"tax\":0"));
            assertTrue(output.startsWith("["));
            assertTrue(output.endsWith("]"));

        } finally {
            System.setOut(originalOut);
        }
    }

    @Test
    void testIntegrationWithProfit() throws Exception {
        String input = "[{\"operation\":\"buy\",\"unit-cost\":10.00,\"quantity\":10000},{\"operation\":\"sell\",\"unit-cost\":20.00,\"quantity\":5000},{\"operation\":\"sell\",\"unit-cost\":5.00,\"quantity\":5000}]";

        ByteArrayInputStream inputStream = new ByteArrayInputStream(input.getBytes(StandardCharsets.UTF_8));
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;

        try {
            System.setIn(inputStream);
            System.setOut(new PrintStream(outputStream));

            Main.main(new String[]{});

            String output = outputStream.toString(StandardCharsets.UTF_8).trim();

            assertTrue(output.contains("\"tax\":10000.00") || output.contains("\"tax\":10000"));
            assertTrue(output.contains("\"tax\":0.00") || output.contains("\"tax\":0"));

        } finally {
            System.setOut(originalOut);
        }
    }

    @Test
    void testIntegrationWithMultipleLines() throws Exception {
        String input = "[{\"operation\":\"buy\",\"unit-cost\":10.00,\"quantity\":100},{\"operation\":\"sell\",\"unit-cost\":15.00,\"quantity\":50}]\n[{\"operation\":\"buy\",\"unit-cost\":20.00,\"quantity\":1000},{\"operation\":\"sell\",\"unit-cost\":25.00,\"quantity\":1000}]";

        ByteArrayInputStream inputStream = new ByteArrayInputStream(input.getBytes(StandardCharsets.UTF_8));
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;

        try {
            System.setIn(inputStream);
            System.setOut(new PrintStream(outputStream));

            Main.main(new String[]{});

            String output = outputStream.toString(StandardCharsets.UTF_8).trim();

            String[] lines = output.split("\n");
            lines = Arrays.stream(lines).filter(line -> !line.trim().isEmpty()).toArray(String[]::new);
            assertEquals(2, lines.length);

            assertTrue(lines[0].contains("\"tax\":0.00") || lines[0].contains("\"tax\":0"));
            assertTrue(lines[1].contains("\"tax\":1000.00") || lines[1].contains("\"tax\":1000"));

        } finally {
            System.setOut(originalOut);
        }
    }


}
